//
//  lab09App.swift
//  lab09
//
//  Created by Ming on 2021/5/26.
//

import SwiftUI

@main
struct lab09App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
