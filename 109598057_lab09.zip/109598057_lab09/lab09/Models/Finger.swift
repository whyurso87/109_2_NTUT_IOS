//
//  Finger.swift
//  lab09
//
//  Created by Ming on 2021/5/26.
//

import Foundation

struct Finger {
    let suit: Suit
    
    enum Suit: String, CaseIterable {
        case rock = "👊"
        case paper = "🖐"
        case scissors = "✌️"
    }
    
}
