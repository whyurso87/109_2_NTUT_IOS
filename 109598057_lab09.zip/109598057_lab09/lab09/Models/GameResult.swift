//
//  GameResult.swift
//  lab09
//
//  Created by Ming on 2021/5/26.
//

import Foundation
enum GameResult {
    case win
    case lose
    case tie
    case defaultR
}

