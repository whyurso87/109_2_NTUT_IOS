//
//  ContentView.swift
//  lab09
//
//  Created by Ming on 2021/5/26.
//



import SwiftUI

struct ContentView: View {
    @StateObject var gameViewModel = GameViewModel()
    var body: some View {
        VStack {
            Text("猜拳遊戲").font(.largeTitle)
            HStack{
                Text("玩家")
                Text(gameViewModel.playerFinger?.suit.rawValue ?? "👊")
                
            } .font(.system(size: 90))
            HStack{
                Text("電腦")
                Text(gameViewModel.computerFinger?.suit.rawValue ?? "👊")
            } .font(.system(size: 90))
            if let result = gameViewModel.result {
                Text(result == .win ? "Win " : "Lose" )
                    .font(.system(size: 50))
            }
            Button(action: {
                gameViewModel.play()
            }, label: {
                Text("出拳！")
            }).font(.title3)
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

