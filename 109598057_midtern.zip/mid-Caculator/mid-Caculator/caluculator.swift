//
//  caluculator.swift
//  mid-Caculator
//
//  Created by Ming on 2021/5/3.
//

import Foundation


class Calculator {
    
    var firstNumber = 0.0
    var firstText = ""
    var secondNumber = 0.0
    var secondText = ""
    var mathOperator = ""
    var output = 0.0
    var outputText = ""
    var complete = false
    func plus() {
        if (complete == true) {
            complete = false
            firstNumber = Double(outputText)!
            firstText = outputText
            secondNumber = 0
            secondText = ""
            outputText = "0"
        }
        else {
            firstNumber = secondNumber
            if (secondNumber - floor(secondNumber) != 0.0){
                firstText = String(secondNumber)
                firstText = String(secondNumber)
            }else{
                firstText = String(Int(secondNumber))
                firstText = String(Int(secondNumber))
            }
            secondNumber = 0
            secondText = ""
            outputText = "0"
        }
        mathOperator = "+"
    }
    
    func minus() {
        if (complete == true) {
            complete = false
            firstNumber = Double(outputText)!
            firstText = outputText
            secondNumber = 0
            secondText = ""
            outputText = "0"
        }
        else {
            firstNumber = secondNumber
            if (secondNumber - floor(secondNumber) != 0.0){
                firstText = String(secondNumber)
                firstText = String(secondNumber)
            }else{
                firstText = String(Int(secondNumber))
                firstText = String(Int(secondNumber))
            }
            secondNumber = 0
            secondText = ""
            outputText = "0"
        }
        mathOperator = "-"
    }
    
    func multiply() {
        if (complete == true) {
            complete = false
            firstNumber = Double(outputText)!
            firstText = outputText
            secondNumber = 0
            secondText = ""
            outputText = "0"
        }
        else {
            firstNumber = secondNumber
            if (secondNumber - floor(secondNumber) != 0.0){
                firstText = String(secondNumber)
                firstText = String(secondNumber)
            }else{
                firstText = String(Int(secondNumber))
                firstText = String(Int(secondNumber))
            }
            secondNumber = 0
            secondText = ""
            outputText = "0"
        }
        mathOperator = "x"
    }
    
    func divide() {
        if (complete == true) {
            complete = false
            firstNumber = Double(outputText)!
            firstText = outputText
            secondNumber = 0
            secondText = ""
            outputText = "0"
        }
        else {
            firstNumber = secondNumber
            if (secondNumber - floor(secondNumber) != 0.0){
                firstText = String(secondNumber)
                firstText = String(secondNumber)
            }else{
                firstText = String(Int(secondNumber))
                firstText = String(Int(secondNumber))
            }
            secondNumber = 0
            secondText = ""
            outputText = "0"
        }
        mathOperator = "÷"
    }
    
    
    
    func PositiveAndNegative() {
        if (complete == false) {
            secondNumber *= -1
            if (secondNumber - floor(secondNumber) != 0.0){
                outputText = String(secondNumber)
                secondText = String(secondNumber)
            }else{
                outputText = String(Int(secondNumber))
                secondText = String(Int(secondNumber))
            }
        }
        else {
            firstNumber *= -1
            if (firstNumber - floor(firstNumber) != 0.0){
                outputText = String(firstNumber)
                firstText = String(firstNumber)
            }else{
                outputText = String(Int(firstNumber))
                firstText = String(Int(firstNumber))
            }
        }
    }
    
    func percentage() {
        if (complete == false) {
            secondNumber /= 100
            if (secondNumber - floor(secondNumber) != 0.0){
                outputText = String(secondNumber)
                secondText = String(secondNumber)
            }else{
                outputText = String(Int(secondNumber))
                secondText = String(Int(secondNumber))
            }
        }
        else {
            firstNumber /= 100
            if (firstNumber - floor(firstNumber) != 0.0){
                outputText = String(firstNumber)
                firstText = String(firstNumber)
            }else{
                outputText = String(Int(firstNumber))
                firstText = String(Int(firstNumber))
            }
        }
    }
    
    
    
    
    
    func equal() {
        switch(mathOperator){
        case "+":
            firstNumber = firstNumber + secondNumber
            complete = true
            output = firstNumber
            if (output - floor(output) != 0.0){
                outputText = String(output)
            }else{
                outputText = String(Int(output))
            }
        case "-":
            firstNumber = firstNumber - secondNumber
            complete = true
            output = firstNumber
            if (output - floor(output) != 0.0){
                outputText = String(output)
            }else{
                outputText = String(Int(output))
            }
        case "x":
            if(secondNumber == 0){
                firstNumber = 0.0
            }else{
                firstNumber = firstNumber*secondNumber
                if(String(firstNumber).replace(target: ".", withString: "").count > 9){
                    let digit = 9 - String(Int(firstNumber)).count
                    firstNumber = firstNumber.rounding(toDecimal: digit)
                }
            }
            complete = true
            output = firstNumber
            if (output - floor(output) != 0.0){
                outputText = String(output)
            }else{
                outputText = String(Int(output))
            }
        case "÷":
            if(secondNumber == 0){
                firstNumber = 0.0
            }else{
                firstNumber = firstNumber/secondNumber
                if(String(firstNumber).replace(target: ".", withString: "").count > 9){
                    let digit = 9 - String(Int(firstNumber)).count
                    firstNumber = firstNumber.rounding(toDecimal: digit)
                }
            }
            complete = true
            output = firstNumber
            if (output - floor(output) != 0.0){
                outputText = String(output)
            }else{
                outputText = String(Int(output))
            }
        default:
            break
        }
        
    }
    
   
    
    
   
    




}

extension Double {
    func rounding(toDecimal decimal: Int) -> Double {
        let numberOfDigits = pow(10.0, Double(decimal))
        return (self * numberOfDigits).rounded(.toNearestOrAwayFromZero) / numberOfDigits
    }
}

extension String{
func replace(target: String, withString: String) -> String
{
return self.replacingOccurrences(of: target, with: withString, options: NSString.CompareOptions.literal, range: nil)
}
}
