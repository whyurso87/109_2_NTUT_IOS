//
//  ContentView.swift
//  lab07
//
//  Created by Ming on 2021/5/5.
//

import SwiftUI

struct ContentView: View {

@State private var showSecondPage = false
@State private var showthridPage = false
@State private var LL = ["海綿","章魚"]
var body: some View {

    VStack{
        Image("2")
Button(action: {
showSecondPage = true
}, label: {
Text("show second page")
})
.sheet(isPresented: $showSecondPage, content: {
    Image("1")
    ZStack {
        
    Color.yellow
    .edgesIgnoringSafeArea(.all)
        ForEach(0..<1) { item in
            Text(LL[item])
        }
    }

})
        Button(action: {
        showthridPage = true
        }, label: {
        Text("show thrid page")
        })
        .sheet(isPresented: $showthridPage, content: {
            Image("3")
            ZStack {
            Color.blue
            .edgesIgnoringSafeArea(.all)
                ForEach(0..<2) { item in
                    Text(LL[item])
                }
            }

        })
}
    
}
}


struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        Group {
            ContentView()
            
        }
    }
}
