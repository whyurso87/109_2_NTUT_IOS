//
//  ContentView.swift
//  lab08
//
//  Created by Ming on 2021/5/12.
//

import SwiftUI

import SwiftUI
struct ContentView: View {
    var roles = ["李白", "李嘉誠", "彼得潘", "奇妙仙子"]
    @State private var selectedIndex = 0
    @State private var word = ""
    @State private var loveBugger = false
    @State private var birthday = Date()
    @State private var weight: CGFloat = 1
    @State var friendValue: Int = 0
    @State private var showAlert = false
    var body: some View {
        VStack {
            Text("海綿寶寶")
            
            Image("1")
            
            Toggle("喜歡美味蟹堡", isOn: $loveBugger)
            
            DatePicker("生日", selection: $birthday)
            
            Stepper("朋友數量: \(friendValue)", value: $friendValue)
                    
            
            Text("體重")
            Slider(value: $weight, in: 0...150)

            
            Picker(selection: $selectedIndex, label: Text("我的朋友是")) {
                
                
                ForEach(roles.indices) { (index) in
                    Text(roles[index])
                }
            }
            
            TextField("口頭禪", text: $word)
            
            
            Button(action: {
                showAlert = true
                   }) {
                       Text("Submit")
                           .font(.system(size: 30))
                           .background(Color.blue)
                           .foregroundColor(.white)
                   }
               
        }.alert(isPresented: $showAlert) { () -> Alert in
            let answer = "送出"
            return Alert(title: Text(answer))}
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
