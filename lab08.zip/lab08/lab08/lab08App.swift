//
//  lab08App.swift
//  lab08
//
//  Created by Ming on 2021/5/12.
//

import SwiftUI

@main
struct lab08App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
